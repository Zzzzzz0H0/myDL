import cv2

ori_image = cv2.imread('/env/images_for_BAIDU_Lane_Segmentation/Gray_Label/Label_road03/Label/Record008/Camera 6/171206_030837506_Camera_6_bin.png', cv2.IMREAD_GRAYSCALE)

print (ori_image.shape)