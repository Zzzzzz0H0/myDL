IMG_SIZE = [1536, 512]
SUBMISSION_SIZE = [3384, 1710]
num_classes = 8
batch_size = 2
base_lr = 0.0006
crop_offset = 690